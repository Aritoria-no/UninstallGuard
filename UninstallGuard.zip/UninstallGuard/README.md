# UninstallGuard

Shows your own custom "Are you sure?" message when you try to uninstall an app (Android Accessibility Service).

## Build on GitHub
Push to GitHub. The Actions tab runs "Build APK". Download the APK from the run's Artifacts.

## Use
1. Open the app, enter an app name + your message, tap Save warning.
2. Tap Enable service and turn on UninstallGuard in Accessibility settings.
   (Android 13+ sideloaded: App info > menu > Allow restricted settings first.)
