# UninstallGuard

Shows your own custom "Are you sure?" message before you uninstall an app.

## Use
1. Open the app, tap an app from your installed list, write your message, Save.
2. Turn on UninstallGuard in Accessibility settings (Android 13+ sideloaded: App info > menu > Allow restricted settings first).
3. Only apps you set a message for get the warning.

## Build on GitHub
Put this zip plus build.yml (at .github/workflows/build.yml) in the repo. Actions builds the APK.
