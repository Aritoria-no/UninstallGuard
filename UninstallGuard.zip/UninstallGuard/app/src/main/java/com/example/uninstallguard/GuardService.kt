package com.example.uninstallguard

import android.accessibilityservice.AccessibilityService
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class GuardService : AccessibilityService() {

    private val handler = Handler(Looper.getMainLooper())
    private var overlay: View? = null
    private var lastPressText = ""
    private var lastPressTime = 0L
    private var suppressUntil = 0L
    private var autoBackUntil = 0L

    private fun isInstaller(pkg: String) =
        pkg.contains("packageinstaller") || pkg.contains("permissioncontroller")

    override fun onAccessibilityEvent(event: AccessibilityEvent) {
        val pkg = event.packageName?.toString() ?: return
        if (pkg == packageName) return
        val now = System.currentTimeMillis()

        when (event.eventType) {
            // Long-press on an app icon (home screen / app drawer): remember its name
            AccessibilityEvent.TYPE_VIEW_LONG_CLICKED -> {
                val t = eventText(event)
                if (t.isNotBlank()) {
                    lastPressText = t
                    lastPressTime = now
                }
            }
            // Tap on "Uninstall" in a launcher menu or Settings: warn BEFORE the system dialog
            AccessibilityEvent.TYPE_VIEW_CLICKED -> {
                if (isInstaller(pkg)) return
                val t = eventText(event).trim().lowercase()
                if (t.startsWith("uninstall")) {
                    var context = collectText(rootInActiveWindow)
                    if (now - lastPressTime < 20000) context += " $lastPressText"
                    handleUninstall(context)
                }
            }
            // The system uninstall dialog itself (covers drag-to-uninstall too)
            AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED -> {
                if (isInstaller(pkg)) checkInstallerWindow(0)
            }
        }
    }

    private fun checkInstallerWindow(attempt: Int) {
        val text = collectText(rootInActiveWindow)
        if (text.lowercase().contains("uninstall")) {
            if (System.currentTimeMillis() < autoBackUntil) {
                autoBackUntil = 0
                performGlobalAction(GLOBAL_ACTION_BACK)
            } else {
                handleUninstall(text)
            }
        } else if (attempt < 3) {
            handler.postDelayed({ checkInstallerWindow(attempt + 1) }, 250)
        }
    }

    private fun handleUninstall(screenText: String) {
        if (overlay != null || System.currentTimeMillis() < suppressUntil) return
        val match = findWarning(screenText) ?: return
        showOverlay(match.first, match.second)
    }

    private fun findWarning(screenText: String): Pair<String, String>? {
        val warnings = getSharedPreferences("warnings", MODE_PRIVATE)
        val labels = getSharedPreferences("labels", MODE_PRIVATE)
        val t = screenText.lowercase()
        var best: Pair<String, String>? = null
        for ((pkg, msg) in warnings.all) {
            val label = labels.getString(pkg, null) ?: continue
            val message = msg as? String ?: continue
            if (label.length >= 2 && t.contains(label.lowercase())) {
                if (best == null || label.length > best.first.length) best = Pair(label, message)
            }
        }
        return best
    }

    private fun eventText(event: AccessibilityEvent): String =
        event.text.joinToString(" ") + " " + (event.contentDescription ?: "")

    private fun collectText(node: AccessibilityNodeInfo?): String {
        if (node == null) return ""
        val sb = StringBuilder()
        sb.append(node.text ?: "").append(' ').append(node.contentDescription ?: "").append(' ')
        for (i in 0 until node.childCount) sb.append(collectText(node.getChild(i)))
        return sb.toString()
    }

    private fun showOverlay(label: String, message: String) {
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val pad = (24 * resources.displayMetrics.density).toInt()

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.WHITE)
            setPadding(pad, pad, pad, pad)
            addView(TextView(context).apply {
                text = "Wait! Uninstall $label?"
                textSize = 20f
                setTextColor(Color.BLACK)
            })
            addView(TextView(context).apply {
                text = message
                textSize = 16f
                setTextColor(Color.DKGRAY)
                setPadding(0, pad / 2, 0, pad / 2)
            })
            addView(Button(context).apply {
                text = "Keep app"
                setOnClickListener {
                    close()
                    autoBackUntil = System.currentTimeMillis() + 4000
                    performGlobalAction(GLOBAL_ACTION_BACK)
                }
            })
            addView(Button(context).apply {
                text = "Uninstall anyway"
                setOnClickListener {
                    suppressUntil = System.currentTimeMillis() + 20000
                    close()
                }
            })
        }

        val dim = LinearLayout(this).apply {
            setBackgroundColor(0xCC000000.toInt())
            gravity = Gravity.CENTER
            setPadding(pad, 0, pad, 0)
            addView(
                box,
                LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                )
            )
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        wm.addView(dim, params)
        overlay = dim
    }

    private fun close() {
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        overlay?.let { runCatching { wm.removeView(it) } }
        overlay = null
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        close()
        super.onDestroy()
    }
}
