package com.example.uninstallguard

import android.accessibilityservice.AccessibilityService
import android.graphics.Color
import android.graphics.PixelFormat
import android.view.Gravity
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class GuardService : AccessibilityService() {

    private var overlay: LinearLayout? = null
    private var lastShown = 0L

    override fun onAccessibilityEvent(event: AccessibilityEvent) {
        if (event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val cls = event.className?.toString() ?: ""
        val pkg = event.packageName?.toString() ?: ""

        val isUninstallScreen = cls.contains("Uninstall", ignoreCase = true) &&
            (pkg.contains("packageinstaller") || pkg.contains("permissioncontroller"))
        if (!isUninstallScreen) return

        // Avoid re-triggering right after the user tapped "Uninstall anyway"
        if (overlay != null || System.currentTimeMillis() - lastShown < 3000) return

        val screenText = collectText(rootInActiveWindow).lowercase()
        val prefs = getSharedPreferences("warnings", MODE_PRIVATE)
        val match = prefs.all.entries.firstOrNull { screenText.contains(it.key) }

        val msg = (match?.value as? String)?.takeIf { it.isNotBlank() }
            ?: "Are you sure you want to uninstall this app?"
        showOverlay(msg)
    }

    private fun collectText(node: AccessibilityNodeInfo?): String {
        if (node == null) return ""
        val sb = StringBuilder(node.text?.toString() ?: "").append(' ')
        for (i in 0 until node.childCount) sb.append(collectText(node.getChild(i)))
        return sb.toString()
    }

    private fun showOverlay(message: String) {
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.WHITE)
            setPadding(64, 64, 64, 48)
            addView(TextView(context).apply {
                text = "Wait!"; textSize = 22f; setTextColor(Color.BLACK)
            })
            addView(TextView(context).apply {
                text = message; textSize = 16f; setTextColor(Color.DKGRAY)
                setPadding(0, 24, 0, 32)
            })
            addView(Button(context).apply {
                text = "Keep app"
                setOnClickListener { close(wm); performGlobalAction(GLOBAL_ACTION_BACK) }
            })
            addView(Button(context).apply {
                text = "Uninstall anyway"
                setOnClickListener { lastShown = System.currentTimeMillis(); close(wm) }
            })
        }

        val dim = LinearLayout(this).apply {
            setBackgroundColor(0xAA000000.toInt())
            gravity = Gravity.CENTER
            setPadding(64, 0, 64, 0)
            addView(box, LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        wm.addView(dim, params)
        overlay = dim
    }

    private fun close(wm: WindowManager) {
        overlay?.let { runCatching { wm.removeView(it) } }
        overlay = null
    }

    override fun onInterrupt() {}
}
