package com.example.uninstallguard

import android.content.Intent
import android.content.SharedPreferences
import android.graphics.drawable.Drawable
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

data class AppItem(val label: String, val pkg: String, val icon: Drawable)

class MainActivity : AppCompatActivity() {

    private lateinit var warnings: SharedPreferences
    private lateinit var labels: SharedPreferences
    private lateinit var adapter: BaseAdapter
    private lateinit var statusText: TextView
    private lateinit var enableBtn: Button
    private val allApps = mutableListOf<AppItem>()
    private val shown = mutableListOf<AppItem>()
    private var query = ""

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        warnings = getSharedPreferences("warnings", MODE_PRIVATE)
        labels = getSharedPreferences("labels", MODE_PRIVATE)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(40), dp(16), dp(8))
        }

        statusText = TextView(this).apply { textSize = 14f }
        enableBtn = Button(this).apply {
            text = "Turn on in Accessibility settings"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }
        val title = TextView(this).apply {
            text = "Tap an app to set its warning"
            textSize = 20f
            setPadding(0, dp(12), 0, dp(8))
        }
        val search = EditText(this).apply {
            hint = "Search apps"
            setSingleLine()
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun afterTextChanged(s: Editable?) {
                    query = s?.toString() ?: ""
                    applyFilter()
                }
            })
        }

        adapter = object : BaseAdapter() {
            override fun getCount() = shown.size
            override fun getItem(position: Int) = shown[position]
            override fun getItemId(position: Int) = position.toLong()
            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                val item = shown[position]
                val ctx = this@MainActivity
                val row = LinearLayout(ctx).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(0, dp(8), 0, dp(8))
                }
                val icon = ImageView(ctx).apply { setImageDrawable(item.icon) }
                row.addView(icon, LinearLayout.LayoutParams(dp(44), dp(44)))

                val col = LinearLayout(ctx).apply {
                    orientation = LinearLayout.VERTICAL
                    setPadding(dp(12), 0, 0, 0)
                }
                col.addView(TextView(ctx).apply { text = item.label; textSize = 16f })
                val msg = warnings.getString(item.pkg, null)
                col.addView(TextView(ctx).apply {
                    text = if (msg != null) "\u2714 $msg" else "No warning"
                    textSize = 12f
                    alpha = 0.7f
                    maxLines = 1
                    ellipsize = TextUtils.TruncateAt.END
                })
                row.addView(col)
                return row
            }
        }

        val listView = ListView(this).apply {
            this.adapter = this@MainActivity.adapter
            setOnItemClickListener { _, _, pos, _ -> editWarning(shown[pos]) }
        }

        root.addView(statusText)
        root.addView(enableBtn)
        root.addView(title)
        root.addView(search)
        root.addView(listView, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)

        loadApps()
    }

    override fun onResume() {
        super.onResume()
        val on = serviceEnabled()
        statusText.text = if (on) "Protection is ON \u2714" else "Protection is OFF. Turn the service on:"
        enableBtn.visibility = if (on) View.GONE else View.VISIBLE
        applyFilter()
    }

    private fun serviceEnabled(): Boolean {
        val enabled = Settings.Secure.getString(
            contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        return enabled.contains("$packageName/") && enabled.contains("GuardService")
    }

    private fun loadApps() {
        Thread {
            val pm = packageManager
            val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val items = pm.queryIntentActivities(intent, 0)
                .filter { it.activityInfo.packageName != packageName }
                .map { AppItem(it.loadLabel(pm).toString(), it.activityInfo.packageName, it.loadIcon(pm)) }
                .distinctBy { it.pkg }
            runOnUiThread {
                allApps.clear()
                allApps.addAll(items)
                applyFilter()
            }
        }.start()
    }

    private fun applyFilter() {
        val q = query.trim().lowercase()
        shown.clear()
        shown.addAll(
            allApps
                .filter { q.isEmpty() || it.label.lowercase().contains(q) }
                .sortedWith(compareBy<AppItem>(
                    { warnings.getString(it.pkg, null) == null },
                    { it.label.lowercase() }
                ))
        )
        adapter.notifyDataSetChanged()
    }

    private fun remove(item: AppItem) {
        warnings.edit().remove(item.pkg).apply()
        labels.edit().remove(item.pkg).apply()
    }

    private fun editWarning(item: AppItem) {
        val input = EditText(this).apply {
            hint = "e.g. You have images saved on this app"
            setText(warnings.getString(item.pkg, ""))
            minLines = 3
            gravity = Gravity.TOP
        }
        val holder = FrameLayout(this).apply {
            setPadding(dp(20), dp(8), dp(20), 0)
            addView(input)
        }
        AlertDialog.Builder(this)
            .setTitle("Warning for ${item.label}")
            .setView(holder)
            .setPositiveButton("Save") { _, _ ->
                val m = input.text.toString().trim()
                if (m.isEmpty()) {
                    remove(item)
                } else {
                    warnings.edit().putString(item.pkg, m).apply()
                    labels.edit().putString(item.pkg, item.label).apply()
                }
                applyFilter()
            }
            .setNeutralButton("Remove") { _, _ -> remove(item); applyFilter() }
            .setNegativeButton("Cancel", null)
            .show()
    }
}
