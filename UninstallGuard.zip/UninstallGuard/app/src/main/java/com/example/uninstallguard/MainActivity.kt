package com.example.uninstallguard

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("warnings", MODE_PRIVATE)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 96, 48, 48)
        }
        val appName = EditText(this).apply { hint = "App name (e.g. Gallery)" }
        val message = EditText(this).apply {
            hint = "Your message (e.g. You have images saved on this app)"
            minLines = 3
        }
        val save = Button(this).apply { text = "Save warning" }
        val enable = Button(this).apply { text = "Enable service (Accessibility)" }
        val list = TextView(this)

        fun refresh() {
            list.text = prefs.all.entries.joinToString("\n\n") { "• ${it.key}: ${it.value}" }
        }

        save.setOnClickListener {
            val name = appName.text.toString().trim().lowercase()
            if (name.isNotEmpty()) {
                prefs.edit().putString(name, message.text.toString().trim()).apply()
                appName.text.clear(); message.text.clear()
                refresh()
            }
        }
        enable.setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        listOf(appName, message, save, enable, list).forEach {
            root.addView(it, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        }
        setContentView(ScrollView(this).apply { addView(root) })
        refresh()
    }
}
